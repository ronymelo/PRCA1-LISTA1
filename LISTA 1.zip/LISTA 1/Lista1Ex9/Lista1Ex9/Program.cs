﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diametro;
            double area;

            Console.WriteLine("\n---------Exercício 9 da Lista 1---------\n");

            Console.Write("Digite o Valor do Diâmetro do Circulo: ");
            diametro = double.Parse(Console.ReadLine());

            area = Math.PI * Math.Pow((diametro / 2),2);

            Console.WriteLine("");
            Console.WriteLine("A Área do Circulo Vale: {0}", area);
        }
    }
}
