﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double mediaG;

            Console.WriteLine("\n---------Exercício 6 da Lista 1---------\n");

            Console.Write("Digite o Primeiro Valor: ");
            valor1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Segundo Valor: ");
            valor2 = double.Parse(Console.ReadLine());

            mediaG = Math.Sqrt(valor1 * valor2);

            Console.WriteLine("");
            Console.WriteLine("A Média Geométrica dos Dois Números Vale: {0}", mediaG);
        }
    }
}
