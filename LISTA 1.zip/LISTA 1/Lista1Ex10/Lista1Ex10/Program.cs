﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valorDolar;
            double valorCotacao;
            double resultado;

            Console.WriteLine("\n---------Exercício 10 da Lista 1---------\n");
          
            Console.Write("Digite o Valor da Cotação do Dólar: R$ ");
            valorCotacao = double.Parse(Console.ReadLine());

            Console.Write("Digite um Valor em Dólares: US$ ");
            valorDolar = double.Parse(Console.ReadLine());

            resultado = valorDolar * valorCotacao;

            Console.WriteLine("");
            Console.WriteLine("Resultado em Reais: {0}", resultado.ToString("C"));
        }
    }
}
