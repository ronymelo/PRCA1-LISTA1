﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double lado;
            double area;

            Console.WriteLine("\n---------Exercício 3 da Lista 1---------\n");

            Console.Write("Digite o Valor da Diagonal do Quadrado: ");
            diagonal = double.Parse(Console.ReadLine());

            lado = diagonal/Math.Sqrt(2);
            area = Math.Pow(lado, 2);

            Console.WriteLine("");
            Console.WriteLine("A Área do Quadrado Vale: {0}", area);
        }
    }
}
