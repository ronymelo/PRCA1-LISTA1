﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double area;

            Console.WriteLine("\n---------Exercício 2 da Lista 1---------\n");

            Console.Write("Digite o Valor da Aresta do Quadrado: ");
            aresta = double.Parse(Console.ReadLine());
                   
            area = Math.Pow(aresta,2);

            Console.WriteLine("");
            Console.WriteLine("A Área do Quadrado Vale: {0}", area);
        }
    }
}
